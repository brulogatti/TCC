let baseUrl = "http://localhost/TCC/ws/";

        function addUser(e){
            e.preventDefault();
            const nome = document.getElementById("nome").value;
            const data_nasc = document.getElementById("data_nasc").value;
            const email = document.getElementById("email").value;
            const senha = document.getElementById("senha").value;
            const tipo = document.getElementById("tipo").value;

            const data = {'nome' : nome, 'data_nasc' : data_nasc, 'email' : email, 'senha' : senha, 'tipo' : tipo};

            try{
                fetch(baseUrl + "addUser.php",{
                method:'POST',
                headers: {'Content-Type' : 'application/json'},
                body:JSON.stringify(data)
                })
                .then(response => response.json())
                .then(data => {
                    const messageElement = document.getElementById("message");
                    if(data.success){
                        messageElement.innerText = data.message;
                        messageElement.classList.remove("error-message");
                        messageElement.classList.add("success-message");
                        document.getElementById("nome").value = "";
                        document.getElementById("data_nasc").value = "";
                        document.getElementById("email").value = "";
                        document.getElementById("senha").value = "";
                        document.getElementById("tipo").value = "";
                        setTimeout(function(){ window.location.href = "login.php"; }, 2000); // Redirecionamento após 2 segundos
                    }else{
                        messageElement.innerText = data.message;
                        messageElement.classList.remove("success-message");
                        messageElement.classList.add("error-message");
                    }
                })
            }catch(erro){
                console.error("Erro ao criar a conta", erro.message);
                const messageElement = document.getElementById("message");
                messageElement.innerText = "Erro ao criar a sua conta";
                messageElement.classList.remove("success-message");
                messageElement.classList.add("error-message");
            }
        }

        document.getElementById("btnAdd").addEventListener("click", addUser);