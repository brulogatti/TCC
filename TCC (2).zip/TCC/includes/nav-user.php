
    <div class="banner">
        <div class="navbar">
            <img src="" class="logo">
            <ul>
                <li><a href="../pages/home.php"> Home </a></li>
                <li><a href="../pages/materiais.php"> Materiais </a></li>
                <li><a href="../pages/monitoring.php"> Monitore </a></li>
                <li><a href="../pages/sobrenos.php"> Sobre nós </a></li>
                <li><a href="../pages/"> Perfil </a></li>
                <li><a id="logout"> Logout </a></li>


              
                </div>     
           </ul>
        </div>
    </div>
