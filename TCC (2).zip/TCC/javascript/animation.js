
document.addEventListener("DOMContentLoaded", function () {
    var h2Animation = document.querySelector(".h2animation");

    function checkScroll() {
        var scrollPosition = window.scrollY + window.innerHeight;
        var elementPosition = h2Animation.offsetTop;

        if (scrollPosition > elementPosition) {
            h2Animation.classList.add("show");
        }
    }

    checkScroll();

    window.addEventListener("scroll", checkScroll);
});

document.addEventListener("DOMContentLoaded", function () {
    var pAnimation = document.querySelector(".panimation");

    function checkScroll() {
        var scrollPosition = window.scrollY + window.innerHeight;
        var elementPosition = pAnimation.offsetTop;

        if (scrollPosition > elementPosition) {
            pAnimation.classList.add("show");
        }
    }

    // Verificar a posição de rolagem inicial
    checkScroll();

    // Verificar a posição de rolagem sempre que houver rolagem na página
    window.addEventListener("scroll", checkScroll);
});

document.addEventListener("DOMContentLoaded", function () {
    var imgabout = document.querySelector(".imgabout");

    function checkScroll() {
        var scrollPosition = window.scrollY + window.innerHeight;
        var elementPosition = imgabout.offsetTop;

        if (scrollPosition > elementPosition) {
            imgabout.classList.add("show");
        }
    }

    checkScroll();

    window.addEventListener("scroll", checkScroll);
});