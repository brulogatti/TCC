<?php
include "../includes/functions.php";


if($_SERVER["REQUEST_METHOD"] === "POST"):
        $nome = $_POST["nome"];
        $data_nasc = $_POST["data_nasc"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $tipo = $_POST["tipo"];

        $result = addUser($nome, $data_nasc, $email, $senha, $tipo);

        if ($result) {
                $response =  ['success' => true, 'message' => 'Cadastro efetuado com sucesso!'];
        } else {
                $response = ['success' => false, 'message' => 'Erro ao cadastrar conta.'];
        }

        header('Content-Type: application/json');
        echo json_encode($response);
endif;




    

  

?>