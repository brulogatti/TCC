const baseUrl = "http://localhost/web/TCCmeu/ws/";


function insereMaterial(e){
    e.preventDefault();

    const form = document.querySelector("#formMaterial");
    const data = new FormData(form);

    try {
        fetch(baseUrl + "adMaterial.php", {
            method: 'POST',
            body: data
        }
        )
            .then(response => response.json())
            .then(data => {
                if (data.success) {

                    const alerta = document.getElementById("alerta");
                    alerta.classList.remove("alert-danger");
                    alerta.classList.add("alert");
                    alerta.classList.add("text-center");
                    alerta.textContent = "Cadastro do material efetuado com sucesso"

                    document.getElementById("nome_material").value = "";
                    document.getElementById("video").value = "";
                    document.getElementById("noticia").value = "";
                    document.getElementById("id_categoria").value = "";
                    document.getElementById("doc").value = "";


                } else {
                
                }
            })
  

    }catch(erro){
        const alerta = document.getElementById("alerta");
        alerta.classList.add("aviso");
        alerta.textContent = "Erro ao cadastrar o material"

    }
}

document.getElementById("addMateria").addEventListener("click", insereMaterial);
