const baseUrl = "http://localhost/web/TCCmeu/ws/";

function insereUsuario(e) {
    e.preventDefault();

    const form = document.querySelector("#formCadastro");

    const data = new FormData(form);
    
    fetch(baseUrl + "addUser.php",{ 
        method:'POST',
        body:data
        }
        )
        .then(response => response.json())
        .then(data => {
            if(data.success){ 
                const alerta = document.getElementById("alerta");
                alerta.classList.remove("alert-danger");
                alerta.classList.add("alert");
                alerta.classList.add(" alert-primary");
                alerta.classList.add("text-center");
                alerta.textContent = "Cadastro efetuado com sucesso"

                document.getElementById("nome").value = "";                
                document.getElementById("sobrenome").value = "";
                document.getElementById("data_nasc").value = "";
                document.getElementById("email").value = "";
                document.getElementById("senha").value = "";
            }else{
                

            }
        }).catch(error => {
            // console.log(error)
            const alerta = document.getElementById("alerta");
            alerta.classList.add("alert");
            alerta.classList.add("alert-primary");
            alerta.classList.add("text-center");
            alerta.textContent = "Usuário cadastrado"
            window.location.href = "http://localhost/web/TCCmeu/pages/login.php";
        });
}

document.getElementById("btnAdd").addEventListener("click", insereUsuario);