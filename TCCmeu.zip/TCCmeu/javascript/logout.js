function logout() {
    localStorage.clear()
    window.location.href = "http://localhost/web/TCCmeu/pages/login.php";
}

document.getElementById("logout").addEventListener("click", logout);