let baseUrl1 = "http://localhost/web/TCCmeu/ws/";

function autenticar(e){
    e.preventDefault();
    document.body.style.display = "none";

    const data = new FormData();

    data.append("id",localStorage.getItem("id"));
    data.append("token",localStorage.getItem("token"));
    tipo = localStorage.getItem("tipo")

    fetch(baseUrl1 + "validateToken.php",{ 
        method:'POST',
        body:data
    })
    .then(response => response.json())
    .then(data => {      
        if(data.success && tipo == 'a'){
            document.body.style.display = "";
        }else{
            localStorage.clear();
            window.location.href = "http://localhost/web/TCCMEU/pages/login.php";
        }
    }).catch(error => {
        console.log(error)
    });
}

document.addEventListener("DOMContentLoaded", autenticar);