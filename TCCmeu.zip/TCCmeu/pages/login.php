<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <title> Conecte-se! </title>
</head>
<body>
    <div class="alerta" id="alerta"></div>

    <div class="wrapper">
        <span class="bg-animate"></span>

        <div class="form-box login">
            <h2> Login </h2>

            <form method="post" id="formLogin">
                <div class="input-box">
                    <input type="text" id="email" name="email" required>
                    <label for="email"> E-mail </label>
                    <i class='bx bxs-user'></i>
                </div>

                <div class="input-box">
                    <input type="password" id="senha" name="senha" required>
                    <label for="password"> Senha </label>
                    <i class='bx bx-show' id="togglePassword"></i>

                    <small id="errSenha" class="errJS"></small>
                </div>

                <button id="btnLogin"  class="btn"> Entrar </button>
                <div class="logreg-link">
                    <p> Ainda não possui uma conta? <a href="../pages/cadastro.php" class="register-link"> Cadastre-se! </a></p>
                </div>
            </form>
        </div>

        <div class="info-text login">
            <h2>Bem vindo!</h2>
            <p>
                Explore o "Bubble", seu guia para a qualidade da água
                e descubra como este robô inovador monitora a turbidez
                para um ambiente aquático mais saudável. 💙🤖
            </p>
        </div>
    </div>
</body>

<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#senha');

    togglePassword.addEventListener('click', function() {
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);

        this.classList.toggle('bx-hide');
        this.classList.toggle('bx-show');
    });
</script>

<script src="../javascript/login.js"></script>

<?php
    include '../includes/footer.php';
?>