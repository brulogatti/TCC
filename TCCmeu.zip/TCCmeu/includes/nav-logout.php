
<div class="banner">
        <div class="navbar">
            <img src="" class="logo">
            <ul>
                <li><a href="../pages/cadastro.php"> Cadastro </a></li>
                <li><a href="../pages/login.php"> Login </a></li>
              
                </div>     
           </ul>
        </div>
    </div>
