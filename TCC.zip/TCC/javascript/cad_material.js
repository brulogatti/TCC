const baseUrl = "http://localhost/WEB/TCC/ws/";


function insereMaterial(e){
    e.preventDefault();

    const form = document.querySelector("#formMaterial");
    const data = new FormData(form);

    try {


    }catch(erro){
        const alerta = document.getElementById("alerta");
        alerta.classList.add("aviso");

    }
}