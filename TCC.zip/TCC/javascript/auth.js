function autenticar(e){
    e.preventDefault();
    document.body.style.display = "none";

    const data = new FormData();

    data.append("id",localStorage.getItem("id"));
    data.append("token",localStorage.getItem("token"));

   let baseUrl = "http://localhost/WEB/TCC/ws/";

    fetch(baseUrl + "validateToken.php",{ 
        method:'POST',
        body:data
    })
    .then(response => response.json())
    .then(data => {            
        if(data.success){
            document.body.style.display = "";
        }else{
            localStorage.clear();
            window.location.href = "http://localhost/WEB/TCC/pages/login.php";
        }
    }).catch(error => {
        console.log(error)
    });

}

document.addEventListener("DOMContentLoaded", autenticar);