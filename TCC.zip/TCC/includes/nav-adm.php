
<div class="banner">
        <div class="navbar">
            <img src="" class="logo">
            <ul>
                <li><a href="../pages/home.php"> Home </a></li>
                <li><a href="../pages/"> Materiais </a></li>
                <li><a href="../pages/monitoring.php"> Monitore </a></li>
                <li><a href="../pages/"> Sobre nós </a></li>
                <button type="button" class="btn btn-dark" id="logout">Logout</button>

            
            </ul>
        </div>
    </div>
