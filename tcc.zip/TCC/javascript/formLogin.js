function getMessage(x){
    switch(x){
        case "errTamSenha": return "Senha deve ter pelo menos 8 caracteres";
        case "errMaiuscula": return "A senha deve ter pelo menos 1 letra maiuscula";
        case "errMinuscula": return "A senha deve ter pelo menos 1 letra minuscula";
        case "errDigito": return "A senha deve ter pelo menos 1 numero";
        case "errEspecial": return "A senha deve ter pelo menos 1 caractere especial (ex: @,$,&)";
        case "errEmail": return "O endereço de email esta inválido!";
        
    }
}

function maskNome(){
   let txtNome = document.getElementById("nome").value;
   let tmpNome = ""
   

   for(let i = 0; i < txtNome.length; i++){
        if(!isDigit(txtNome[i])){
            tmpNome = tmpNome + txtNome[i];
        }
   }

   document.getElementById("nome").value = tmpNome;
}

function isDigit(x){
    return !isNaN(parseInt(x));
}

function checkNome(){
    let txtNome = document.getElementById("nome").value;
    let errNome = document.getElementById("errNome");

    if(txtNome.length < 3){
        errNome.textContent = getMessage("erroNome");
    }else{
        errNome.textContent = "";
    }
}

function checkSenha(){
    let txtSenha = document.getElementById("senha").value;
    let errSenha = document.getElementById("errSenha");
    
    let temMinuscula = false;
    let temMaiuscula = false;
    let temDigito = false;
    let temEspecial = false;

    if(txtSenha.length < 8){
        errSenha.textContent = getMessage("errTamSenha");
        return;
    }

    for(let i = 0; i < txtSenha.length; i++){
        if(isMaiuscula(txtSenha[i])){
            temMaiuscula = true;
        }

        if(isMinuscula(txtSenha[i])){
            temMinuscula = true;
        }

        if(isDigit(txtSenha[i])){
            temDigito = true;
        }

        if(!isMaiuscula(txtSenha[i]) && !isMinuscula(txtSenha[i]) && !isDigit(txtSenha[i])){
            temEspecial = true;
        }
    }

    if(!temMaiuscula){
        errSenha.textContent = getMessage("errMaiuscula");
        return;
    }

    if(!temMinuscula){
        errSenha.textContent = getMessage("errMinuscula");
        return;
    }

    if(!temDigito){
        errSenha.textContent = getMessage("errDigito");
        return;
    }

    if(!temEspecial){
        errSenha.textContent = getMessage("errEspecial");
        return;
    }

    errSenha.textContent = "";
}
function isValidEmail(x) {
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(x);
  }

function checkEmail() {
    let txtEmail = document.getElementById("email").value;
    let errEmail = document.getElementById("errEmail");

    if (!isValidEmail(txtEmail)) {
       errEmail.textContent = getMessage("errEmail");
    } else {
        errEmail.textContent = "";
    }
}


function checkForm(event){
    let elementos = document.getElementsByClassName("erro")

    for(let i = 0; i < elementos.length; i++){
        if(elementos[i].textContent != ""){
            event.preventDefault()
            return;            
        }        
    }
}

document.getElementById("email").addEventListener("blur", checkEmail);
document.getElementById("senha").addEventListener("blur",checkSenha)
document.getElementById("btnAdd").addEventListener("submit",checkForm)