function logout() {
    localStorage.clear()
    window.location.href = "http://localhost/TCC/pages/login.php";
}

document.getElementById("logout").addEventListener("click", logout);