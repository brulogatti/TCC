
<div class="banner">
        <div class="navbar">
            <img src="" class="logo">
            <ul>
                <li><a href="../pages/home.php"> Home </a></li>
                <li><a href="../pages/materiais.php"> materiais </a></li>
                <li><a href="../pages/monitoring.php"> monitoramento</a></li>
                <li><a href="../pages/add_categoria.php"> categoria </a></li>
                <li><a href="../pages/"> Perfil </a></li>
                <li><a id="logout"> Logout </a></li>


              
                </div>     
           </ul>
        </div>
    </div>
    <script src="../javascript/logout.js"></script>